# Forest FPS Mobile — Godot 4

Playable procedural FPS prototype, landscape-first and designed for mobile touch.

## Open
1. Install Godot 4.3 or newer.
2. Import `project.godot`.
3. Press F6/F5 to run. Desktop controls: WASD, mouse look, left click fire, R reload, Space jump, Esc release mouse.
4. For Android: Project > Export, install Android build template, configure Android SDK/JDK, then export APK.

## Current implementation
- First-person CharacterBody3D controller and raycast shooting.
- Procedural forest made from low-poly meshes (no external assets required).
- Enemy humanoid silhouettes with chase/attack AI and health.
- Wave spawning, kill score, reload, game-over and restart.
- Landscape HUD, left-side movement touch region, right-side look region, large FIRE/RELOAD/JUMP/PAUSE controls.
- Quality preference module, pickup, damage number and object-pool modules.

## Performance notes
The project uses Compatibility renderer, primitive meshes and restrained object counts. It is a starter baseline, not a verified 60 FPS guarantee. Test on the target Android device and adjust tree count, shadow settings and resolution based on profiling.

## Source size
Core gameplay scripts are authored as modular source. This is an initial playable foundation, not a claim that every planned feature (full skeletal animations, authored terrain textures, audio, or polished settings menu) is complete.
