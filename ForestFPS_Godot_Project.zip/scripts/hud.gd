extends CanvasLayer
signal fire_pressed
signal reload_pressed
signal pause_pressed
signal jump_pressed
var root: Control
var hp_label: Label
var ammo_label: Label
var wave_label: Label
var score_label: Label
var message_label: Label
var game_over_panel: PanelContainer
var joystick_origin := Vector2.ZERO
var joystick_value := Vector2.ZERO
var joystick_active := false
var look_active := false
var look_last := Vector2.ZERO
var player_ref: Node
var fire_button: Button
var reload_button: Button

func _ready() -> void:
    _build_ui()
    _layout()
    get_viewport().size_changed.connect(_layout)

func _build_ui() -> void:
    root = Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(root)
    hp_label = _label("HP 100", 24)
    hp_label.position = Vector2(24, 18)
    root.add_child(hp_label)
    wave_label = _label("WAVE 1", 22)
    wave_label.anchor_left = 0.5
    wave_label.anchor_right = 0.5
    wave_label.position = Vector2(-70, 18)
    root.add_child(wave_label)
    score_label = _label("KILL 0  |  SCORE 0", 18)
    score_label.position = Vector2(24, 54)
    root.add_child(score_label)
    ammo_label = _label("30 / 90", 25)
    ammo_label.anchor_left = 1
    ammo_label.anchor_right = 1
    ammo_label.position = Vector2(-170, -72)
    ammo_label.anchor_top = 1
    ammo_label.anchor_bottom = 1
    root.add_child(ammo_label)
    message_label = _label("", 25)
    message_label.anchor_left = 0.5
    message_label.anchor_right = 0.5
    message_label.position = Vector2(-220, 80)
    message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    root.add_child(message_label)
    _button("Ⅱ", Vector2(-76, 18), Vector2(58, 54), _pause)
    fire_button = _button("FIRE", Vector2(-150, -160), Vector2(118, 118), _fire)
    fire_button.anchor_left = 1
    fire_button.anchor_right = 1
    fire_button.anchor_top = 1
    fire_button.anchor_bottom = 1
    reload_button = _button("RELOAD", Vector2(-275, -82), Vector2(108, 62), _reload)
    reload_button.anchor_left = 1
    reload_button.anchor_right = 1
    reload_button.anchor_top = 1
    reload_button.anchor_bottom = 1
    var jump := _button("JUMP", Vector2(-165, -290), Vector2(86, 64), _jump)
    jump.anchor_left = 1
    jump.anchor_right = 1
    jump.anchor_top = 1
    jump.anchor_bottom = 1
    game_over_panel = PanelContainer.new()
    game_over_panel.visible = false
    game_over_panel.anchor_left = 0.5
    game_over_panel.anchor_top = 0.5
    game_over_panel.anchor_right = 0.5
    game_over_panel.anchor_bottom = 0.5
    game_over_panel.offset_left = -180
    game_over_panel.offset_top = -100
    game_over_panel.offset_right = 180
    game_over_panel.offset_bottom = 100
    root.add_child(game_over_panel)
    var v := VBoxContainer.new()
    game_over_panel.add_child(v)
    var title := _label("MISSION FAILED", 28)
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    v.add_child(title)
    var retry := Button.new()
    retry.text = "RESTART"
    retry.custom_minimum_size = Vector2(0, 56)
    retry.pressed.connect(_restart)
    v.add_child(retry)

func _label(text_value: String, size: int) -> Label:
    var l := Label.new()
    l.text = text_value
    l.add_theme_font_size_override("font_size", size)
    l.add_theme_color_override("font_color", Color(0.94, 0.96, 0.88))
    l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.8))
    l.add_theme_constant_override("shadow_offset_x", 2)
    l.add_theme_constant_override("shadow_offset_y", 2)
    return l

func _button(text_value: String, pos: Vector2, size: Vector2, callback: Callable) -> Button:
    var b := Button.new()
    b.text = text_value
    b.position = pos
    b.size = size
    b.custom_minimum_size = size
    b.add_theme_font_size_override("font_size", 21)
    b.add_theme_color_override("font_color", Color.WHITE)
    b.add_theme_stylebox_override("normal", _button_style(Color(0.08, 0.12, 0.10, 0.78)))
    b.add_theme_stylebox_override("pressed", _button_style(Color(0.45, 0.22, 0.08, 0.95)))
    b.pressed.connect(callback)
    root.add_child(b)
    return b

func _button_style(c: Color) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = c
    s.corner_radius_top_left = 18
    s.corner_radius_top_right = 18
    s.corner_radius_bottom_left = 18
    s.corner_radius_bottom_right = 18
    s.border_width_left = 2
    s.border_width_right = 2
    s.border_width_top = 2
    s.border_width_bottom = 2
    s.border_color = Color(0.75, 0.78, 0.65, 0.8)
    return s

func _layout() -> void:
    if not is_instance_valid(root):
        return
    var size := get_viewport().get_visible_rect().size
    # Landscape-first safe placement; UI scales with the shorter screen edge.
    var unit := clampf(size.y / 720.0, 0.72, 1.25)
    for control in root.get_children():
        if control is Button:
            control.scale = Vector2.ONE * unit

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        var half := get_viewport().get_visible_rect().size.x * 0.5
        if event.pressed and event.position.x < half and event.position.y > get_viewport().get_visible_rect().size.y * 0.48:
            joystick_active = true
            joystick_origin = event.position
            _move_player(Vector2.ZERO)
        elif not event.pressed and joystick_active:
            joystick_active = false
            _move_player(Vector2.ZERO)
        if event.pressed and event.position.x >= half:
            look_active = true
            look_last = event.position
        elif not event.pressed and event.position.x >= half:
            look_active = false
    elif event is InputEventScreenDrag:
        var half2 := get_viewport().get_visible_rect().size.x * 0.5
        if joystick_active and event.position.x < half2:
            var delta := (event.position - joystick_origin) / 75.0
            joystick_value = delta.limit_length(1.0)
            _move_player(joystick_value)
        elif look_active and event.position.x >= half2:
            var delta_look := event.position - look_last
            look_last = event.position
            if is_instance_valid(player_ref):
                player_ref.mobile_look(delta_look)

func _move_player(v: Vector2) -> void:
    if is_instance_valid(player_ref):
        player_ref.set_mobile_move(v)

func set_status(hp: float, ammo: int, reserve: int, wave: int, kills: int, score: int) -> void:
    if not is_instance_valid(hp_label):
        return
    hp_label.text = "HP %03d" % int(hp)
    ammo_label.text = "%02d / %03d" % [ammo, reserve]
    wave_label.text = "WAVE %02d" % wave
    score_label.text = "KILL %d  |  SCORE %d" % [kills, score]

func show_message(value: String, duration: float) -> void:
    message_label.text = value
    await get_tree().create_timer(duration).timeout
    if is_instance_valid(message_label) and message_label.text == value:
        message_label.text = ""

func show_game_over(score: int, wave: int) -> void:
    game_over_panel.visible = true
    message_label.text = "SCORE %d  •  WAVE %d" % [score, wave]

func _fire() -> void:
    fire_pressed.emit()

func _reload() -> void:
    reload_pressed.emit()

func _pause() -> void:
    pause_pressed.emit()

func _jump() -> void:
    jump_pressed.emit()

func _restart() -> void:
    get_tree().paused = false
    get_tree().reload_current_scene()
