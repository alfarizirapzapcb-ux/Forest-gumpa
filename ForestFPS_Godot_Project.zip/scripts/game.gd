extends Node3D
## Main game director: builds the arena, HUD, player, enemies and wave loop.
const PLAYER = preload("res://scripts/player.gd")
const ENEMY = preload("res://scripts/enemy.gd")
const HUD = preload("res://scripts/hud.gd")
const WORLD = preload("res://scripts/world_builder.gd")
var player: CharacterBody3D
var hud: CanvasLayer
var wave := 1
var kills := 0
var score := 0
var alive_enemies := 0
var spawn_clock := 0.0
var spawn_remaining := 0
var game_over := false
var paused := false

func _ready() -> void:
    _setup_environment()
    WORLD.new().build(self)
    player = PLAYER.new()
    player.name = "Player"
    add_child(player)
    player.global_position = Vector3(0, 1.2, 8)
    player.died.connect(_on_player_died)
    hud = HUD.new()
    add_child(hud)
    hud.player_ref = player
    hud.fire_pressed.connect(_on_fire)
    hud.reload_pressed.connect(_on_reload)
    hud.pause_pressed.connect(_on_pause)
    hud.jump_pressed.connect(_on_jump)
    hud.set_status(100, 30, 90, wave, kills, score)
    _begin_wave()

func _process(delta: float) -> void:
    if paused or game_over:
        return
    if spawn_remaining > 0:
        spawn_clock -= delta
        if spawn_clock <= 0.0:
            _spawn_enemy()
            spawn_remaining -= 1
            spawn_clock = maxf(0.65, 1.7 - wave * 0.035)
    if alive_enemies == 0 and spawn_remaining == 0:
        await get_tree().create_timer(2.0).timeout
        if not game_over and alive_enemies == 0:
            wave += 1
            _begin_wave()
    if is_instance_valid(player):
        hud.set_status(player.health, player.ammo, player.reserve, wave, kills, score)

func _setup_environment() -> void:
    var env := WorldEnvironment.new()
    var e := Environment.new()
    e.background_mode = Environment.BG_SKY
    e.sky = Sky.new()
    e.sky.sky_material = ProceduralSkyMaterial.new()
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color(0.55, 0.62, 0.52)
    e.ambient_light_energy = 0.7
    e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.environment = e
    add_child(env)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -28, 0)
    sun.light_energy = 1.1
    sun.shadow_enabled = true
    add_child(sun)

func _begin_wave() -> void:
    spawn_remaining = 4 + wave * 2
    spawn_clock = 0.5
    hud.show_message("WAVE %d — MUSUH MENDEKAT" % wave, 2.0)

func _spawn_enemy() -> void:
    if game_over:
        return
    var enemy = ENEMY.new()
    add_child(enemy)
    var angle := randf() * TAU
    var radius := randf_range(17.0, 25.0)
    enemy.global_position = Vector3(cos(angle) * radius, 0, sin(angle) * radius)
    enemy.target = player
    enemy.died.connect(_on_enemy_died)
    alive_enemies += 1

func _on_enemy_died(value: int) -> void:
    alive_enemies = maxi(0, alive_enemies - 1)
    kills += 1
    score += value
    hud.show_message("+%d SCORE" % value, 0.8)

func _on_player_died() -> void:
    game_over = true
    hud.show_game_over(score, wave)

func _on_fire() -> void:
    if not game_over and not paused:
        player.shoot()

func _on_reload() -> void:
    if not game_over:
        player.reload()

func _on_jump() -> void:
    if not game_over:
        player.request_jump()

func _on_pause() -> void:
    paused = not paused
    get_tree().paused = paused
    hud.show_message("PAUSED" if paused else "RESUMED", 1.0)

func restart() -> void:
    get_tree().paused = false
    get_tree().reload_current_scene()
