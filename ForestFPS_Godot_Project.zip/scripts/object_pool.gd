extends Node
## Reusable node pool to avoid frequent allocation spikes.
var pools: Dictionary = {}
var scenes: Dictionary = {}
var pool_root: Node3D

func _ready() -> void:
    pool_root = Node3D.new()
    pool_root.name = "InactivePool"
    add_child(pool_root)

func register_pool(key: String, packed_scene: PackedScene, initial_size: int) -> void:
    scenes[key] = packed_scene
    pools[key] = []
    for i in range(maxi(0, initial_size)):
        var instance := packed_scene.instantiate()
        pool_root.add_child(instance)
        instance.set_process(false)
        instance.set_physics_process(false)
        instance.hide()
        pools[key].append(instance)

func acquire(key: String, parent: Node) -> Node:
    if not pools.has(key):
        return null
    var bucket: Array = pools[key]
    var instance: Node
    if bucket.is_empty():
        instance = scenes[key].instantiate()
        pool_root.add_child(instance)
    else:
        instance = bucket.pop_back()
    if instance.get_parent() != parent:
        instance.reparent(parent)
    instance.show()
    instance.set_process(true)
    instance.set_physics_process(true)
    if instance.has_method("on_pool_acquired"):
        instance.on_pool_acquired()
    return instance

func release(key: String, instance: Node) -> void:
    if not pools.has(key) or not is_instance_valid(instance):
        return
    if instance.has_method("on_pool_released"):
        instance.on_pool_released()
    instance.hide()
    instance.set_process(false)
    instance.set_physics_process(false)
    instance.reparent(pool_root)
    pools[key].append(instance)

func clear_pool(key: String) -> void:
    if not pools.has(key):
        return
    for instance in pools[key]:
        if is_instance_valid(instance):
            instance.queue_free()
    pools[key].clear()
