extends CharacterBody3D
signal died
const SPEED := 6.2
const JUMP_VELOCITY := 5.0
const SENSITIVITY := 0.0022
var health := 100.0
var ammo := 30
var reserve := 90
var reloading := false
var fire_cooldown := 0.0
var jump_requested := false
var look_delta := Vector2.ZERO
var move_vector := Vector2.ZERO
var camera: Camera3D
var weapon_root: Node3D
var muzzle: MeshInstance3D
var touch_look := false

func _ready() -> void:
    _build_body()
    _build_camera()
    Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _build_body() -> void:
    var collision := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.38
    capsule.height = 1.8
    collision.shape = capsule
    collision.position.y = 0.9
    add_child(collision)

func _build_camera() -> void:
    camera = Camera3D.new()
    camera.position = Vector3(0, 1.58, 0)
    camera.fov = 78
    camera.current = true
    add_child(camera)
    weapon_root = Node3D.new()
    weapon_root.position = Vector3(0.32, -0.28, -0.62)
    camera.add_child(weapon_root)
    var body := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = Vector3(0.16, 0.18, 0.62)
    body.mesh = mesh
    body.position = Vector3(0, 0, -0.18)
    body.material_override = _mat(Color(0.075, 0.09, 0.08))
    weapon_root.add_child(body)
    var barrel := MeshInstance3D.new()
    var bm := CylinderMesh.new()
    bm.top_radius = 0.025
    bm.bottom_radius = 0.035
    bm.height = 0.42
    barrel.mesh = bm
    barrel.rotation.x = PI / 2
    barrel.position.z = -0.52
    barrel.material_override = _mat(Color(0.025, 0.03, 0.028))
    weapon_root.add_child(barrel)
    muzzle = MeshInstance3D.new()
    var flash := SphereMesh.new()
    flash.radius = 0.11
    flash.height = 0.2
    muzzle.mesh = flash
    muzzle.position.z = -0.75
    muzzle.material_override = _mat(Color(1.0, 0.62, 0.12))
    muzzle.visible = false
    weapon_root.add_child(muzzle)

func _mat(color: Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = 0.82
    return m

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        rotate_y(-event.relative.x * SENSITIVITY)
        camera.rotate_x(-event.relative.y * SENSITIVITY)
        camera.rotation.x = clampf(camera.rotation.x, -1.35, 1.35)
    if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _physics_process(delta: float) -> void:
    fire_cooldown = maxf(0.0, fire_cooldown - delta)
    if not is_on_floor():
        velocity.y -= 18.0 * delta
    elif jump_requested:
        velocity.y = JUMP_VELOCITY
    jump_requested = false
    var input := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
    input += move_vector
    input = input.limit_length(1.0)
    var direction := (transform.basis * Vector3(input.x, 0, input.y)).normalized()
    velocity.x = move_toward(velocity.x, direction.x * SPEED, 24.0 * delta)
    velocity.z = move_toward(velocity.z, direction.z * SPEED, 24.0 * delta)
    move_and_slide()
    weapon_root.position.y = -0.28 + sin(Time.get_ticks_msec() * 0.008) * 0.012 * velocity.length()
    if muzzle.visible:
        await get_tree().create_timer(0.055).timeout
        if is_instance_valid(muzzle):
            muzzle.visible = false

func set_mobile_move(v: Vector2) -> void:
    move_vector = v.limit_length(1.0)

func mobile_look(v: Vector2) -> void:
    rotate_y(-v.x * SENSITIVITY * 2.0)
    camera.rotate_x(-v.y * SENSITIVITY * 2.0)
    camera.rotation.x = clampf(camera.rotation.x, -1.35, 1.35)

func shoot() -> void:
    if reloading or fire_cooldown > 0.0:
        return
    if ammo <= 0:
        reload()
        return
    ammo -= 1
    fire_cooldown = 0.105
    muzzle.visible = true
    weapon_root.position.z = -0.52
    var from := camera.global_position
    var to := from + -camera.global_transform.basis.z * 100.0
    var query := PhysicsRayQueryParameters3D.create(from, to)
    query.exclude = [self]
    var hit := get_world_3d().direct_space_state.intersect_ray(query)
    if hit and hit.collider.has_method("take_damage"):
        hit.collider.take_damage(34.0)

func reload() -> void:
    if reloading or ammo >= 30 or reserve <= 0:
        return
    reloading = true
    await get_tree().create_timer(1.35).timeout
    if not is_inside_tree():
        return
    var needed := 30 - ammo
    var loaded := mini(needed, reserve)
    ammo += loaded
    reserve -= loaded
    reloading = false

func request_jump() -> void:
    jump_requested = true

func take_damage(amount: float) -> void:
    if health <= 0:
        return
    health = maxf(0.0, health - amount)
    if health <= 0:
        died.emit()
