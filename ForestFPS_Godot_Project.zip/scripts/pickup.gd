extends Area3D
signal collected(kind: String, amount: int)
var kind := "ammo"
var amount := 30
var spin_speed := 1.4
var bob_phase := 0.0
var mesh_node: MeshInstance3D

func _ready() -> void:
    var shape := CollisionShape3D.new()
    var sphere := SphereShape3D.new()
    sphere.radius = 0.9
    shape.shape = sphere
    add_child(shape)
    mesh_node = MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = Vector3(0.55, 0.55, 0.55)
    mesh_node.mesh = box
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.2, 0.65, 0.9) if kind == "ammo" else Color(0.2, 0.9, 0.35)
    mat.emission_enabled = true
    mat.emission = mat.albedo_color
    mesh_node.material_override = mat
    add_child(mesh_node)
    body_entered.connect(_on_body_entered)

func _process(delta: float) -> void:
    bob_phase += delta
    mesh_node.rotation.y += spin_speed * delta
    mesh_node.position.y = sin(bob_phase * 2.0) * 0.12

func _on_body_entered(body: Node3D) -> void:
    if body is CharacterBody3D and body.has_method("take_pickup"):
        body.take_pickup(kind, amount)
        collected.emit(kind, amount)
        queue_free()
