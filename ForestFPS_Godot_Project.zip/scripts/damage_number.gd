extends Label3D
## Lightweight floating damage feedback.
var lifetime := 0.65
var rise_speed := 1.2
var fade_start := 0.3

func configure(value: int, critical: bool = false) -> void:
    text = str(value)
    font_size = 48 if critical else 34
    modulate = Color(1.0, 0.72, 0.2) if critical else Color.WHITE
    outline_size = 8
    billboard = BaseMaterial3D.BILLBOARD_ENABLED

func _process(delta: float) -> void:
    lifetime -= delta
    position.y += rise_speed * delta
    if lifetime < fade_start:
        modulate.a = clampf(lifetime / fade_start, 0.0, 1.0)
    if lifetime <= 0:
        queue_free()
