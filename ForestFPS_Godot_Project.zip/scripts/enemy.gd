extends CharacterBody3D
signal died(points: int)
var target: Node3D
var health := 100.0
var speed := 2.5
var attack_range := 1.8
var attack_timer := 0.0
var dead := false
var body_mesh: MeshInstance3D
var head_mesh: MeshInstance3D
var hit_flash := 0.0

func _ready() -> void:
    speed += randf_range(-0.35, 0.55)
    _build_enemy()

func _build_enemy() -> void:
    var shape := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.38
    capsule.height = 1.75
    shape.shape = capsule
    shape.position.y = 0.88
    add_child(shape)
    body_mesh = MeshInstance3D.new()
    var torso := CapsuleMesh.new()
    torso.radius = 0.34
    torso.height = 1.05
    body_mesh.mesh = torso
    body_mesh.position.y = 1.05
    body_mesh.material_override = _material(Color(0.22, 0.25, 0.19))
    add_child(body_mesh)
    head_mesh = MeshInstance3D.new()
    var head := SphereMesh.new()
    head.radius = 0.22
    head.height = 0.44
    head_mesh.mesh = head
    head_mesh.position.y = 1.78
    head_mesh.material_override = _material(Color(0.55, 0.39, 0.29))
    add_child(head_mesh)
    var legs := MeshInstance3D.new()
    var legmesh := BoxMesh.new()
    legmesh.size = Vector3(0.48, 0.68, 0.28)
    legs.mesh = legmesh
    legs.position.y = 0.38
    legs.material_override = _material(Color(0.12, 0.15, 0.12))
    add_child(legs)

func _material(c: Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = 1.0
    return m

func _physics_process(delta: float) -> void:
    if dead or not is_instance_valid(target):
        return
    attack_timer = maxf(0.0, attack_timer - delta)
    hit_flash = maxf(0.0, hit_flash - delta)
    if hit_flash > 0:
        body_mesh.material_override.albedo_color = Color(1, 0.25, 0.2)
    else:
        body_mesh.material_override.albedo_color = Color(0.22, 0.25, 0.19)
    var offset := target.global_position - global_position
    offset.y = 0
    var distance := offset.length()
    if distance > attack_range:
        var dir := offset.normalized()
        velocity.x = dir.x * speed
        velocity.z = dir.z * speed
        look_at(Vector3(target.global_position.x, global_position.y, target.global_position.z))
    else:
        velocity.x = move_toward(velocity.x, 0, 12 * delta)
        velocity.z = move_toward(velocity.z, 0, 12 * delta)
        if attack_timer <= 0:
            target.take_damage(8.0)
            attack_timer = 1.1
    if not is_on_floor():
        velocity.y -= 18 * delta
    move_and_slide()

func take_damage(amount: float) -> void:
    if dead:
        return
    health -= amount
    hit_flash = 0.12
    if health <= 0:
        dead = true
        died.emit(100)
        queue_free()
