extends RefCounted
## Deterministic low-cost procedural forest dressing.
const TREE_COUNT := 95
const ROCK_COUNT := 42
var rng := RandomNumberGenerator.new()
var trunk_material: StandardMaterial3D
var leaf_material: StandardMaterial3D
var rock_material: StandardMaterial3D
var ground_material: StandardMaterial3D

func build(root: Node3D) -> void:
    rng.randomize()
    _make_materials()
    _ground(root)
    _create_forest_ring(root)
    _scatter_trees(root)
    _scatter_rocks(root)
    _create_path(root)
    _create_landmarks(root)

func _make_materials() -> void:
    trunk_material = _mat(Color(0.19, 0.12, 0.075))
    leaf_material = _mat(Color(0.12, 0.23, 0.13))
    rock_material = _mat(Color(0.27, 0.29, 0.25))
    ground_material = _mat(Color(0.20, 0.18, 0.12))

func _mat(c: Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = 1.0
    return m

func _ground(root: Node3D) -> void:
    var mesh := MeshInstance3D.new()
    var plane := PlaneMesh.new()
    plane.size = Vector2(100, 100)
    mesh.mesh = plane
    mesh.material_override = ground_material
    root.add_child(mesh)
    var body := StaticBody3D.new()
    var col := CollisionShape3D.new()
    var box := BoxShape3D.new()
    box.size = Vector3(100, 0.3, 100)
    col.shape = box
    col.position.y = -0.2
    body.add_child(col)
    root.add_child(body)

func _create_forest_ring(root: Node3D) -> void:
    for i in range(32):
        var angle := TAU * float(i) / 32.0
        var p := Vector3(cos(angle) * 43, 0, sin(angle) * 43)
        _tree(root, p, rng.randf_range(0.8, 1.5))

func _scatter_trees(root: Node3D) -> void:
    for i in range(TREE_COUNT):
        var p := Vector3(rng.randf_range(-38, 38), 0, rng.randf_range(-38, 38))
        if absf(p.x) < 4.0 and p.z > -8 and p.z < 18:
            continue
        _tree(root, p, rng.randf_range(0.75, 1.45))

func _tree(root: Node3D, p: Vector3, scale_factor: float) -> void:
    var trunk := MeshInstance3D.new()
    var cylinder := CylinderMesh.new()
    cylinder.top_radius = 0.22
    cylinder.bottom_radius = 0.38
    cylinder.height = 3.6
    trunk.mesh = cylinder
    trunk.position = p + Vector3(0, 1.8, 0)
    trunk.scale = Vector3.ONE * scale_factor
    trunk.material_override = trunk_material
    root.add_child(trunk)
    var crown := MeshInstance3D.new()
    var cone := ConeMesh.new()
    cone.bottom_radius = 1.65
    cone.height = 4.0
    crown.mesh = cone
    crown.position = p + Vector3(0, 4.1 * scale_factor, 0)
    crown.scale = Vector3.ONE * scale_factor
    crown.material_override = leaf_material
    root.add_child(crown)

func _scatter_rocks(root: Node3D) -> void:
    for i in range(ROCK_COUNT):
        var rock := MeshInstance3D.new()
        var sphere := SphereMesh.new()
        sphere.radius = rng.randf_range(0.3, 0.9)
        sphere.height = sphere.radius * 1.3
        rock.mesh = sphere
        rock.position = Vector3(rng.randf_range(-40, 40), sphere.radius * 0.4, rng.randf_range(-40, 40))
        rock.scale = Vector3(rng.randf_range(0.8, 1.8), rng.randf_range(0.5, 1.0), rng.randf_range(0.8, 1.5))
        rock.material_override = rock_material
        root.add_child(rock)

func _create_path(root: Node3D) -> void:
    var path := MeshInstance3D.new()
    var plane := PlaneMesh.new()
    plane.size = Vector2(5.5, 65)
    path.mesh = plane
    path.position = Vector3(0, 0.012, -10)
    path.material_override = _mat(Color(0.29, 0.24, 0.15))
    root.add_child(path)

func _create_landmarks(root: Node3D) -> void:
    _crate(root, Vector3(-5, 0.5, -8))
    _crate(root, Vector3(5, 0.5, -18))
    _crate(root, Vector3(-7, 0.5, 12))

func _crate(root: Node3D, p: Vector3) -> void:
    var node := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = Vector3(1.2, 1.0, 1.2)
    node.mesh = box
    node.position = p
    node.material_override = _mat(Color(0.28, 0.20, 0.11))
    root.add_child(node)
