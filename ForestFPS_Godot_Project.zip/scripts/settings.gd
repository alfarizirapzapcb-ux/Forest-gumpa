extends Node
## Centralized quality and input preferences.
enum Quality { LOW, MEDIUM, HIGH }
var quality: Quality = Quality.LOW
var master_volume := 0.8
var mouse_sensitivity := 1.0
var mobile_sensitivity := 1.0
var show_fps := true
var shadows_enabled := false
var particles_enabled := true
var max_active_enemies := 18
var render_scale := 0.8

func apply_quality(value: int) -> void:
    quality = clampi(value, Quality.LOW, Quality.HIGH)
    match quality:
        Quality.LOW:
            shadows_enabled = false
            particles_enabled = false
            max_active_enemies = 12
            render_scale = 0.7
        Quality.MEDIUM:
            shadows_enabled = false
            particles_enabled = true
            max_active_enemies = 18
            render_scale = 0.85
        Quality.HIGH:
            shadows_enabled = true
            particles_enabled = true
            max_active_enemies = 28
            render_scale = 1.0

func set_volume(value: float) -> void:
    master_volume = clampf(value, 0.0, 1.0)
    var bus := AudioServer.get_bus_index("Master")
    AudioServer.set_bus_volume_linear(bus, master_volume)

func set_mouse_sensitivity(value: float) -> void:
    mouse_sensitivity = clampf(value, 0.2, 2.5)

func set_mobile_sensitivity(value: float) -> void:
    mobile_sensitivity = clampf(value, 0.2, 3.0)

func save_preferences() -> void:
    var config := ConfigFile.new()
    config.set_value("video", "quality", quality)
    config.set_value("audio", "volume", master_volume)
    config.set_value("input", "mouse", mouse_sensitivity)
    config.set_value("input", "mobile", mobile_sensitivity)
    config.save("user://settings.cfg")

func load_preferences() -> void:
    var config := ConfigFile.new()
    if config.load("user://settings.cfg") != OK:
        return
    apply_quality(int(config.get_value("video", "quality", Quality.LOW)))
    set_volume(float(config.get_value("audio", "volume", 0.8)))
    set_mouse_sensitivity(float(config.get_value("input", "mouse", 1.0)))
    set_mobile_sensitivity(float(config.get_value("input", "mobile", 1.0)))
