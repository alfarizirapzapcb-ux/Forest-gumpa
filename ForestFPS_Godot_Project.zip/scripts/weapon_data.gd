extends Resource
class_name WeaponData
@export var weapon_name := "Ranger Rifle"
@export var damage := 34.0
@export var magazine_size := 30
@export var reserve_capacity := 180
@export var fire_interval := 0.105
@export var reload_duration := 1.35
@export var spread_degrees := 0.6
@export var recoil_pitch := 0.018
@export var recoil_yaw := 0.008
@export var automatic := true
@export var headshot_multiplier := 2.0

func validate() -> void:
    magazine_size = maxi(1, magazine_size)
    reserve_capacity = maxi(0, reserve_capacity)
    damage = maxf(1.0, damage)
    fire_interval = clampf(fire_interval, 0.04, 2.0)
    reload_duration = clampf(reload_duration, 0.2, 8.0)

func total_ammo(current: int, reserve: int) -> int:
    return maxi(0, current) + maxi(0, reserve)

func can_fire(current: int, cooldown: float, is_reloading: bool) -> bool:
    return current > 0 and cooldown <= 0 and not is_reloading

func ammo_needed(current: int) -> int:
    return maxi(0, magazine_size - current)

func reload_amount(current: int, reserve: int) -> int:
    return mini(ammo_needed(current), maxi(0, reserve))
